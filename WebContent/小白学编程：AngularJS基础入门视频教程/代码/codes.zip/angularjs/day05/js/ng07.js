var app = angular.module('myApp', []); 


app.controller('RouteController', ['$scope', function($scope) {
	
	$scope.path="pages/1.html";


}]);
